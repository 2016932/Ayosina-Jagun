<?php
$editData = $_POST;

// Add your validation and save data to database

echo 'Saved Successfully';
?>