<!-- Static navbar -->
<nav class="navbar-expand-md navbar-dark fixed-top" id="navigation">
    <div class="container-fluid navbar">
        <div class="navbar-header" id="comInfo">
            <button class="navbar-toggler" data-toggle="collapse" data-target="#content">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- <img src="pictures/xmas.png" class="myImage animate__animated animate__fadeInLeft" alt="riverside agropro wishes you merry xmas and happy new year"> -->
            <a href="homepage.php" id="projectName" class="animate__animated animate__zoomInDown">
                <img src="pictures/icon.png" alt="" srcset="">
                <span>Daily Task Web Application</span>
            </a>
        </div>
        
        <!-- <div id="content" class="collapse navbar-collapse animate__animated animate__slideInLeft">
       </div> -->
    </div>
</nav>